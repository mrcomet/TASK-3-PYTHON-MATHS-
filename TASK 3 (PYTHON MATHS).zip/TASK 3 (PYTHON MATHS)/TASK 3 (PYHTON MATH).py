#!/usr/bin/env python
# coding: utf-8

# # Q1. Polar Coordinates
# 
# 

# In[ ]:


import cmath
z= input()
print (abs(complex(z)))
print (cmath.phase(complex(z)))


# # Q2. Find Angle MBC

# In[ ]:


import math
ab = int(input())
bc = int(input())
H = math.sqrt(ab**2 + bc**2)
H = H/2.0
adj = bc/2.0
res = int(round(math.degrees(math.acos(adj/H))))
res = str(res)
print(res+"°")


# # Q3. Triangle Quest 2
# 
# 

# In[1]:


for i in range(1, int(input()) + 1):  
    print((10 ** i - 1) ** 2 // 81)


# # Q4. Mod Divmod

# In[ ]:


a = divmod(int(input()), int(input()))
print(*a, a, sep='\n')


# # Q5. Power - Mod Power

# In[ ]:


a = int(input().strip())
b = int(input().strip())
c = int(input().strip())
    
print(pow(a, b))
print(pow(a, b, c))


# # Q6. Integers Come In All Sizes
# 
# 

# In[ ]:


a=int(input())
b=int(input())
c=int(input())
d=int(input())
print(a**b+c**d)


# # Q7. Triangle Quest
# 

# In[ ]:


for i in range(1, int(input()) + 1):  
    print (((10**i - 1)//9)**2)

